//
//  PZProtocol.h
//  PZSpeed
//
//  Created by Rocir Marcos Leite Santiago on 10/31/13.
//  Copyright (c) 2013 PacketZoom. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PZProtocol : NSURLProtocol
@end
